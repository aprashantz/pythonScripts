#this function is used to convert given numbers into binary
def dectobin(num):
    value=num
    binaryContainer=[]
    actualBinary=[]
    actualBinaryNum=""
    counter=0
    while counter != 8:
        remainder=value%2
        binaryContainer.append(remainder)
        value=value//2
        counter+=1
    for i in range(len(binaryContainer)-1,-1,-1):
        actualBinary.append(binaryContainer[i])
        actualBinaryNum=actualBinaryNum+str(binaryContainer[i])
    return actualBinaryNum

#this function is used to take input from user and use (dectobin) function to get value in binary form
def conversion():
    try:
        print("\n")
        input1=int(input("\t\tFirst decimal number:"))
        input2=int(input("\t\tSecond decimal number:"))
        global suminput     #making global so that it can be used in another function 
        suminput= input1 + input2
        global bin1,bin2    #making global so that binary values can be used in (addition) function to find binary sum
        bin1=(dectobin(input1))
        bin2=(dectobin(input2))
        easyBin1= bin1.lstrip("0")  #lstrip is used to remove given value from leading or left part
        easyBin2= bin2.lstrip("0")
        
        if( (0<= input1 <=255) and (0<= input2 <=255) and (0<= suminput <=255) ):
            print("\n")
            print("\t|||--------------------------------------|||")
            print("\t\tDECIMAL-BINARY CONVERSION:")
            print("\t\t",input1,"=",easyBin1)
            print("\t\t",input2,"=",easyBin2)
            print("\t|||--------------------------------------|||")

        else:   #to warn  user when input values are not in range of (0-255) 
            print("\n")
            print("\t\t!!! INVALID INPUT !!!")
            print("\t\tPlease enter values within range of (0-255)\n\t\tThe sum of your two values also should be less than 255 to get correct binary addition.")
            print("\t--------------------------------------------------")

    except: #to handle error when user gives empty or string value
        print("\n")
        print("\t\t!!! INVALID INPUT !!!")
        print("\t\tYou cannot give alphabetical or empty value\n\t\tPlease input numeric values only.")
        print("\t--------------------------------------------------")
        conversion()    #here conversion method is called so that if user give empty or string value, it repeats input taking step 

#this function gets binary values from (conversion) function and adds two bin values using bit adder, full adder logic gate     
def addition():
    try:
        if (suminput <=255 and (bin1 != "" or bin2 != "") ):
            value1= list(bin1)
            value2=list(bin2)
            output=''
            intvalue1 = [int(index) for index in value1]
            intvalue2 = [int(index) for index in value2]
            position=7
            container=[0,0,0,0,0,0,0,0]
            carryin=0
            carryout=0
            while(position > -1):
                container[position]= (intvalue1[position] ^ intvalue2[position])  ^ carryin   #sumContainer logic= output of XOR gate using in Binaddition of column and carryover
                carryout= ( carryin & (intvalue1[position] ^ intvalue2[position]) ) | ( intvalue1[position] & intvalue2[position] ) #carryover logic= taking carry value from previous Binaddition
                carryin=carryout
                position -=1
            for i in range(0,len(container)):
                output= output+str(container[i])
                finaloutput= output.lstrip("0")     #lstrip is used to remove given value from leading or left part
            print("\t|||--------------------------------------|||")
            print("\t\tBINARY ADDITION:")
            print("\t\t",bin1,"\n","\t\t+"+bin2)
            print("\t\t----------")
            print("\t\t",output)
            print("\t\tSum:",finaloutput)
            print("\t|||---------------------------------------||")
            print("\n")

    except:
        print("\t***************************************************")



