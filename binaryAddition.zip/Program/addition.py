#this function is used to find binary sum of converted binary numbers
def binadd(num1,num2):
    output=""
    binary1=[]
    binary2=[]
    for each in num1:
        binary1.append(int(each))
    for each in num2:
        binary2.append(int(each))
    position=7
    container=[0,0,0,0,0,0,0,0]
    carryin=0
    carryout=0
    while(position > -1):
        container[position]= binary1[position] ^ binary2[position]  ^ carryin   #using XOR gate to add each value from right side of container's list  
        carryout= ( carryin & (binary1[position] ^ binary2[position]) ) | ( binary1[position] & binary2[position] )
        carryin=carryout #using two carry variables just to be clear how carryover value works 
        position -=1    #to perform calculation in each element of the list from 7th to 0 position
    for i in range(0,len(container)):
        output= output+str(container[i])    #to store sum value as a single number
    return output
