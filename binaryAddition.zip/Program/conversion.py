#this function is used to convert given numbers into binary
def dectobin(decimalnumber):
    descendingRemainder=[]
    singlebinaryvalue=""
    counter=0
    while counter != 8:
        remainder=decimalnumber%2
        descendingRemainder.append(remainder)
        decimalnumber=decimalnumber//2
        counter+=1
    for i in range(len(descendingRemainder)-1,-1,-1):
        singlebinaryvalue=singlebinaryvalue+str(descendingRemainder[i])     #to store binary value as a single number from below to top remainder list
    return singlebinaryvalue

