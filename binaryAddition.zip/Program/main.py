#importing necessary modules to use
import greetingmessage
import conversion
import exceptionhandle
import addition

greetingmessage.displayStart()  #shows welcome message

continueLoop=True   #to restart program when user wants to remath
while continueLoop==True:
    input1=exceptionhandle.inputchecker()   #calling function which take decimal input
    print("\t\tFirst decimal number:",input1)

    input2=exceptionhandle.inputchecker()
    print("\t\tSecond decimal number:",input2)

    print("\t\tGiven numbers are:","[",input1,"and",input2,"]")

    #using funcution from other module to perform conversion and binary addition
    bin1=conversion.dectobin(input1)
    bin2=conversion.dectobin(input2)
    easyBin1=exceptionhandle.extrazero(bin1)  
    easyBin2=exceptionhandle.extrazero(bin2)
    binarysum=addition.binadd(bin1,bin2)
    finalsum=exceptionhandle.extrazero(binarysum)

    print("\n")
    print("\t|||--------------------------------------|||")
    print("\t\tDECIMAL-BINARY CONVERSION:")
    print("\t\t",input1,"=",easyBin1)
    print("\t\t",input2,"=",easyBin2)
    print("\t|||--------------------------------------|||")
    print("\n")

    print("\t|||--------------------------------------|||")
    print("\t\tBINARY ADDITION:")
    print("\t\t",bin1,"\n","\t\t+"+bin2)
    print("\t\t----------")
    print("\t\t",binarysum)
    print("\t\tSum:",finalsum)
    print("\t|||---------------------------------------||")
    print("\n")

    restartloop=True    #to repeatidly ask for command multiple times unless user gives yes/no instruction
    while restartloop==True:
        command=input("\n\tPress |ENTER| button to continue program or Type 'exit' to close:").lower()
        if command=="":
            continueLoop=True
            restartloop=False   #setting restartloop false to stop asking exit or restart command
        elif command=="exit":
            continueLoop=False #setting false to stop program by taking out of loop
            print("\n")
            greetingmessage.displayEnd() #shows exit message while out of loop
            break
        elif command != "":
            restartloop=True
        
