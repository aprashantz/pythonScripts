#this function is used to print necessary notice when user gives value beyond range
def beyondrange():
    print("\t\t!!! INVALID INPUT !!!")
    print("\t\tPlease enter value within range of (0-255)")
    print("\t--------------------------------------------------")

#this function is used to print necessary notice when user does not give integer value
def beyondint():
    print("\t\t!!! INVALID INPUT !!!")
    print("\t\tPlease input numeric values only.")
    print("\t--------------------------------------------------")
    print("\n")

def extrazero(num):
    showingvalue=""
    if num=="00000000":
        showingvalue="0"
        return showingvalue
    else:
        showingvalue=num.lstrip("0")    #lstrip is used to remove given value from leading or left part
    return showingvalue

#this function takes decimal input as well as handles exception
def inputchecker():
    inputloop=True
    while inputloop==True:
        try:
            number=int(input("\tNumber:"))
            if number in range(0,256):
                inputloop=False
                return number
            else:
                beyondrange()
                inputloop=True
        except:
            beyondint()
            inputloop=True
