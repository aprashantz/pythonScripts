#this function is used to show welcome message
def displayStart():
    print("\n")
    print("\t","__________________________________________")
    print("\t*||> Welcome to Binary Addition Program <||*")
    print("\t","******************************************")
    print("\n")

#this function is used to show message when user chooses to exit
def displayEnd():
    print("\t||||||||||||||||||||||||||||||||||||||||||||||")
    print("\t|||||> Thank you for using this program <|||||")
    print("\t|||||>      Hope to see you again     <|||||||")
    print("\t|||||>          GOOD BYE!!!      <||||||||||||")
    print("\t||||||||||||||||||||||||||||||||||||||||||||||")
